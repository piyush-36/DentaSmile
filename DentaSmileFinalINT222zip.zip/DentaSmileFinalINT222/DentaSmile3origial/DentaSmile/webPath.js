import express from 'express';
import { join } from 'path';
const route = express();
import userDetailSchema from './schema.js';
import mongoose from 'mongoose';

const userDetail = new mongoose.model("userDetail", userDetailSchema);

route.use(express.static('assets'));

route.get('/services',(req,res)=>{
    res.sendFile(join(process.cwd(),'assets','/html/Services.html'));
})

route.get('/blog',(req,res)=>{
    res.sendFile(join(process.cwd(),'assets','/html/blog.html'));
})

route.get('/contact',(req,res)=>{
    res.sendFile(join(process.cwd(),'assets','/html/contact.html'));
})

route.get('/about',(req,res)=>{
    res.sendFile(join(process.cwd(),'assets','/html/about.html'));
})

route.get('/appointment',(req,res)=>{
    res.sendFile(join(process.cwd(),'assets','/html/appointment.html'));
})

route.post('/appointment',async (req,res)=>{
    try{
        const user = new userDetail({
        name : req.body.name,
        email : req.body.email,
        phone : req.body.phone,
        Date : req.body.Date,
        time : req.body.time,
        message : req.body.message
        })

        const result = await user.save();
        res.sendFile(join(process.cwd(),'assets','/html/appointment.html'))
    }catch(err){
        console.log(err);
    }
})

route.get('/home',(req,res)=>{
    res.sendFile(join(process.cwd(),'assets','/html/index.html'));
})

route.get('/',(req,res)=>{
    res.sendFile(join(process.cwd(),'assets','/html/index.html'));
})

export default route;