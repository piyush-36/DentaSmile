import express from 'express';
import mongoose from 'mongoose';
import bodyParser from 'body-parser';
import { fileURLToPath } from 'url';
import path, { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const port = 3000;

// Connect to MongoDB (assuming MongoDB is running locally)
mongoose.connect('mongodb://localhost:27017/mydatabase');

// Define a schema and model for emails
const emailSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true
  }
});
const Email = mongoose.model('Email', emailSchema);

app.use(bodyParser.urlencoded({ extended: true }));
// app.use(express.static(path.join(dirname(fileURLToPath(import.meta.url)), 'assets')));
app.use(express.static(path.join(__dirname, 'assets')));


// Home route to serve HTML form
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'assets', 'html', 'index.html'));
});

// POST route to handle form submission
app.post('/submitEmail', async (req, res) => {
  console.log(req.body);
  const { email } = req.body;

  try {
    // Create a new Email document and save it to MongoDB
    const newEmail = new Email({ email });
    await newEmail.save({ validateBeforeSave: false });
    res.json({ success: true, message: 'Email submitted successfully!' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Error submitting email.' });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
