import mongoose from "mongoose";

const userDetailSchema = new mongoose.Schema({
    name:{
        type: String
    },
    email:{
        type: String
    },
    phone:{
        type: Number
    },
    Date:{
        type: String
    },
    time:{
        type: String
    },
    message:{
        type: String
    }
})
export default userDetailSchema;